using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DenemeScripti : MonoBehaviour
{
    void bolenleriBul(int a, int b)
    {
        // T�m Say�lar� Yazd�ran Kod
       
        string sayilar = "";

        for (int i = a; i < b + 1; i++)
        {
            sayilar += " - " + i;
        }

        print("T�m Say�lar: " + sayilar);

        //--------------------------


        //�kiye B�l�nenler

         string ikiyeBolunenler = "";

        for (int i = a; i < b + 1; i++)
        {          
            if (i % 2 == 0)
            {
                ikiyeBolunenler += " - " + i;          
            }           
        }
        print("�kiye B�l�nenler: " + ikiyeBolunenler);

        //--------------------------


        //��e B�l�nenler

        string uceBolunenler = "";

        for (int i = a; i < b + 1; i++)
        {
            if (i % 3 == 0)
            {
                uceBolunenler += " - " + i;
            }
        }
        print("��e B�l�nenler: " + uceBolunenler);

        //--------------------------


        //D�rde B�l�nenler

        string dordeBolunenler = "";

        for (int i = a; i < b + 1; i++)
        {
            if (i % 4 == 0)
            {
                dordeBolunenler += " - " + i;
            }
        }
        print("D�rde B�l�nenler: " + dordeBolunenler);

        //--------------------------


        //Be�e B�l�nenler

        string beseBolunenler = "";

        for (int i = a; i < b + 1; i++)
        {
            if (i % 5 == 0)
            {
                beseBolunenler += " - " + i;
            }
        }
        print("Be�e B�l�nenler: " + beseBolunenler);

        //--------------------------

    }



    // Start is called before the first frame update
    void Start()
    {
        bolenleriBul(7, 39);
    }

    // Update is called once per frame
    void Update()
    {
               
    }


    
}
